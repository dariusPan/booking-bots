# task-bots/__init__.py

"""
Booking Bot Package

This package contains modules to automate booking tasks using Selenium.
"""
